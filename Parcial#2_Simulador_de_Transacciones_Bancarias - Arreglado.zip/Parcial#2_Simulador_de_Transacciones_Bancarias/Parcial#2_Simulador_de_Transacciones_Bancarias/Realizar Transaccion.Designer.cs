﻿namespace Parcial_2_Simulador_de_Transacciones_Bancarias
{
    partial class Realizar_Transaccion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Realizar_Transaccion));
            this.lbCuentaDestinoNuevaTransaccion = new System.Windows.Forms.Label();
            this.rbtnCuenta1 = new System.Windows.Forms.RadioButton();
            this.rbtnCuenta2 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.lbMontoNuevaTransaccion = new System.Windows.Forms.Label();
            this.txtMontoNuevaTransaccion = new System.Windows.Forms.TextBox();
            this.btnSiguienteNuevaTransaccion = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbCuentaDestinoNuevaTransaccion
            // 
            this.lbCuentaDestinoNuevaTransaccion.AutoSize = true;
            this.lbCuentaDestinoNuevaTransaccion.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCuentaDestinoNuevaTransaccion.Location = new System.Drawing.Point(44, 170);
            this.lbCuentaDestinoNuevaTransaccion.Name = "lbCuentaDestinoNuevaTransaccion";
            this.lbCuentaDestinoNuevaTransaccion.Size = new System.Drawing.Size(218, 38);
            this.lbCuentaDestinoNuevaTransaccion.TabIndex = 0;
            this.lbCuentaDestinoNuevaTransaccion.Text = "Cuenta Destino";
            // 
            // rbtnCuenta1
            // 
            this.rbtnCuenta1.AutoSize = true;
            this.rbtnCuenta1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnCuenta1.Location = new System.Drawing.Point(301, 178);
            this.rbtnCuenta1.Name = "rbtnCuenta1";
            this.rbtnCuenta1.Size = new System.Drawing.Size(121, 29);
            this.rbtnCuenta1.TabIndex = 1;
            this.rbtnCuenta1.TabStop = true;
            this.rbtnCuenta1.Text = "Cuenta 1";
            this.rbtnCuenta1.UseVisualStyleBackColor = true;
            // 
            // rbtnCuenta2
            // 
            this.rbtnCuenta2.AutoSize = true;
            this.rbtnCuenta2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnCuenta2.Location = new System.Drawing.Point(473, 179);
            this.rbtnCuenta2.Name = "rbtnCuenta2";
            this.rbtnCuenta2.Size = new System.Drawing.Size(121, 29);
            this.rbtnCuenta2.TabIndex = 2;
            this.rbtnCuenta2.TabStop = true;
            this.rbtnCuenta2.Text = "Cuenta 2";
            this.rbtnCuenta2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Green;
            this.label2.Location = new System.Drawing.Point(489, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(311, 45);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nueva Transacción";
            // 
            // lbMontoNuevaTransaccion
            // 
            this.lbMontoNuevaTransaccion.AutoSize = true;
            this.lbMontoNuevaTransaccion.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMontoNuevaTransaccion.Location = new System.Drawing.Point(156, 273);
            this.lbMontoNuevaTransaccion.Name = "lbMontoNuevaTransaccion";
            this.lbMontoNuevaTransaccion.Size = new System.Drawing.Size(106, 38);
            this.lbMontoNuevaTransaccion.TabIndex = 4;
            this.lbMontoNuevaTransaccion.Text = "Monto";
            // 
            // txtMontoNuevaTransaccion
            // 
            this.txtMontoNuevaTransaccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMontoNuevaTransaccion.Location = new System.Drawing.Point(268, 273);
            this.txtMontoNuevaTransaccion.Name = "txtMontoNuevaTransaccion";
            this.txtMontoNuevaTransaccion.Size = new System.Drawing.Size(286, 38);
            this.txtMontoNuevaTransaccion.TabIndex = 6;
            this.txtMontoNuevaTransaccion.TextChanged += new System.EventHandler(this.txtMontoNuevaTransaccion_TextChanged);
            // 
            // btnSiguienteNuevaTransaccion
            // 
            this.btnSiguienteNuevaTransaccion.BackColor = System.Drawing.Color.OliveDrab;
            this.btnSiguienteNuevaTransaccion.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSiguienteNuevaTransaccion.Location = new System.Drawing.Point(242, 402);
            this.btnSiguienteNuevaTransaccion.Name = "btnSiguienteNuevaTransaccion";
            this.btnSiguienteNuevaTransaccion.Size = new System.Drawing.Size(226, 57);
            this.btnSiguienteNuevaTransaccion.TabIndex = 11;
            this.btnSiguienteNuevaTransaccion.Text = "Siguiente";
            this.btnSiguienteNuevaTransaccion.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(720, 192);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(474, 267);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // Realizar_Transaccion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1243, 659);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnSiguienteNuevaTransaccion);
            this.Controls.Add(this.txtMontoNuevaTransaccion);
            this.Controls.Add(this.lbMontoNuevaTransaccion);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rbtnCuenta2);
            this.Controls.Add(this.rbtnCuenta1);
            this.Controls.Add(this.lbCuentaDestinoNuevaTransaccion);
            this.Name = "Realizar_Transaccion";
            this.Text = "Realizar_Transaccion";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbCuentaDestinoNuevaTransaccion;
        private System.Windows.Forms.RadioButton rbtnCuenta1;
        private System.Windows.Forms.RadioButton rbtnCuenta2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbMontoNuevaTransaccion;
        private System.Windows.Forms.TextBox txtMontoNuevaTransaccion;
        private System.Windows.Forms.Button btnSiguienteNuevaTransaccion;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}