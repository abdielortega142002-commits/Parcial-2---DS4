﻿namespace Parcial_2_Simulador_de_Transacciones_Bancarias
{
    partial class PantallaConfirmacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PantallaConfirmacion));
            this.label2 = new System.Windows.Forms.Label();
            this.lbMontoEnviarConfirmacion = new System.Windows.Forms.Label();
            this.txtMontoNuevaTransaccion = new System.Windows.Forms.TextBox();
            this.lbCuentaOrigenConfirmacion = new System.Windows.Forms.Label();
            this.lbCuentaDestinoConfirmacion = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnSiguienteNuevaTransaccion = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Green;
            this.label2.Location = new System.Drawing.Point(514, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(229, 45);
            this.label2.TabIndex = 4;
            this.label2.Text = "Confirmación";
            // 
            // lbMontoEnviarConfirmacion
            // 
            this.lbMontoEnviarConfirmacion.AutoSize = true;
            this.lbMontoEnviarConfirmacion.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMontoEnviarConfirmacion.Location = new System.Drawing.Point(113, 139);
            this.lbMontoEnviarConfirmacion.Name = "lbMontoEnviarConfirmacion";
            this.lbMontoEnviarConfirmacion.Size = new System.Drawing.Size(218, 38);
            this.lbMontoEnviarConfirmacion.TabIndex = 5;
            this.lbMontoEnviarConfirmacion.Text = "Monto a Enviar";
            // 
            // txtMontoNuevaTransaccion
            // 
            this.txtMontoNuevaTransaccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMontoNuevaTransaccion.Location = new System.Drawing.Point(387, 139);
            this.txtMontoNuevaTransaccion.Name = "txtMontoNuevaTransaccion";
            this.txtMontoNuevaTransaccion.Size = new System.Drawing.Size(286, 38);
            this.txtMontoNuevaTransaccion.TabIndex = 7;
            // 
            // lbCuentaOrigenConfirmacion
            // 
            this.lbCuentaOrigenConfirmacion.AutoSize = true;
            this.lbCuentaOrigenConfirmacion.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCuentaOrigenConfirmacion.Location = new System.Drawing.Point(125, 228);
            this.lbCuentaOrigenConfirmacion.Name = "lbCuentaOrigenConfirmacion";
            this.lbCuentaOrigenConfirmacion.Size = new System.Drawing.Size(206, 38);
            this.lbCuentaOrigenConfirmacion.TabIndex = 8;
            this.lbCuentaOrigenConfirmacion.Text = "Cuenta Origen";
            // 
            // lbCuentaDestinoConfirmacion
            // 
            this.lbCuentaDestinoConfirmacion.AutoSize = true;
            this.lbCuentaDestinoConfirmacion.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCuentaDestinoConfirmacion.Location = new System.Drawing.Point(113, 314);
            this.lbCuentaDestinoConfirmacion.Name = "lbCuentaDestinoConfirmacion";
            this.lbCuentaDestinoConfirmacion.Size = new System.Drawing.Size(218, 38);
            this.lbCuentaDestinoConfirmacion.TabIndex = 9;
            this.lbCuentaDestinoConfirmacion.Text = "Cuenta Destino";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(387, 229);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(286, 38);
            this.textBox1.TabIndex = 10;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(387, 314);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(286, 38);
            this.textBox2.TabIndex = 11;
            // 
            // btnSiguienteNuevaTransaccion
            // 
            this.btnSiguienteNuevaTransaccion.BackColor = System.Drawing.Color.OliveDrab;
            this.btnSiguienteNuevaTransaccion.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSiguienteNuevaTransaccion.Location = new System.Drawing.Point(284, 441);
            this.btnSiguienteNuevaTransaccion.Name = "btnSiguienteNuevaTransaccion";
            this.btnSiguienteNuevaTransaccion.Size = new System.Drawing.Size(226, 57);
            this.btnSiguienteNuevaTransaccion.TabIndex = 14;
            this.btnSiguienteNuevaTransaccion.Text = "Confirmar";
            this.btnSiguienteNuevaTransaccion.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.OliveDrab;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(735, 441);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(226, 57);
            this.button1.TabIndex = 15;
            this.button1.Text = "Corregir";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(748, 129);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(427, 237);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // PantallaConfirmacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1214, 692);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnSiguienteNuevaTransaccion);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbCuentaDestinoConfirmacion);
            this.Controls.Add(this.lbCuentaOrigenConfirmacion);
            this.Controls.Add(this.txtMontoNuevaTransaccion);
            this.Controls.Add(this.lbMontoEnviarConfirmacion);
            this.Controls.Add(this.label2);
            this.Name = "PantallaConfirmacion";
            this.Text = "PantallaConfirmacion";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbMontoEnviarConfirmacion;
        private System.Windows.Forms.TextBox txtMontoNuevaTransaccion;
        private System.Windows.Forms.Label lbCuentaOrigenConfirmacion;
        private System.Windows.Forms.Label lbCuentaDestinoConfirmacion;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnSiguienteNuevaTransaccion;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}