﻿namespace Parcial_2_Simulador_de_Transacciones_Bancarias
{
    partial class PantallaExito
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PantallaExito));
            this.label2 = new System.Windows.Forms.Label();
            this.lbMontoEnviarConfirmacion = new System.Windows.Forms.Label();
            this.lbCuentaOrigenTransaccionExitosa = new System.Windows.Forms.Label();
            this.lbCuentaDestinoTransaccionExitosa = new System.Windows.Forms.Label();
            this.txtMontoNuevaTransaccion = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePickerFechaTransaccion = new System.Windows.Forms.DateTimePicker();
            this.btnSiguienteNuevaTransaccion = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Green;
            this.label2.Location = new System.Drawing.Point(411, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(344, 45);
            this.label2.TabIndex = 5;
            this.label2.Text = "¡Transacción Exitosa!";
            // 
            // lbMontoEnviarConfirmacion
            // 
            this.lbMontoEnviarConfirmacion.AutoSize = true;
            this.lbMontoEnviarConfirmacion.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMontoEnviarConfirmacion.Location = new System.Drawing.Point(158, 154);
            this.lbMontoEnviarConfirmacion.Name = "lbMontoEnviarConfirmacion";
            this.lbMontoEnviarConfirmacion.Size = new System.Drawing.Size(218, 38);
            this.lbMontoEnviarConfirmacion.TabIndex = 6;
            this.lbMontoEnviarConfirmacion.Text = "Monto Enviado";
            // 
            // lbCuentaOrigenTransaccionExitosa
            // 
            this.lbCuentaOrigenTransaccionExitosa.AutoSize = true;
            this.lbCuentaOrigenTransaccionExitosa.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCuentaOrigenTransaccionExitosa.Location = new System.Drawing.Point(170, 249);
            this.lbCuentaOrigenTransaccionExitosa.Name = "lbCuentaOrigenTransaccionExitosa";
            this.lbCuentaOrigenTransaccionExitosa.Size = new System.Drawing.Size(206, 38);
            this.lbCuentaOrigenTransaccionExitosa.TabIndex = 7;
            this.lbCuentaOrigenTransaccionExitosa.Text = "Cuenta Origen";
            // 
            // lbCuentaDestinoTransaccionExitosa
            // 
            this.lbCuentaDestinoTransaccionExitosa.AutoSize = true;
            this.lbCuentaDestinoTransaccionExitosa.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCuentaDestinoTransaccionExitosa.Location = new System.Drawing.Point(158, 337);
            this.lbCuentaDestinoTransaccionExitosa.Name = "lbCuentaDestinoTransaccionExitosa";
            this.lbCuentaDestinoTransaccionExitosa.Size = new System.Drawing.Size(218, 38);
            this.lbCuentaDestinoTransaccionExitosa.TabIndex = 8;
            this.lbCuentaDestinoTransaccionExitosa.Text = "Cuenta Destino";
            // 
            // txtMontoNuevaTransaccion
            // 
            this.txtMontoNuevaTransaccion.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMontoNuevaTransaccion.Location = new System.Drawing.Point(454, 155);
            this.txtMontoNuevaTransaccion.Name = "txtMontoNuevaTransaccion";
            this.txtMontoNuevaTransaccion.ReadOnly = true;
            this.txtMontoNuevaTransaccion.Size = new System.Drawing.Size(286, 43);
            this.txtMontoNuevaTransaccion.TabIndex = 9;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(454, 250);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(286, 43);
            this.textBox1.TabIndex = 10;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(454, 338);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(286, 43);
            this.textBox2.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(53, 437);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(323, 38);
            this.label4.TabIndex = 12;
            this.label4.Text = "Fecha de la Transacción";
            // 
            // dateTimePickerFechaTransaccion
            // 
            this.dateTimePickerFechaTransaccion.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerFechaTransaccion.Location = new System.Drawing.Point(454, 437);
            this.dateTimePickerFechaTransaccion.Name = "dateTimePickerFechaTransaccion";
            this.dateTimePickerFechaTransaccion.Size = new System.Drawing.Size(422, 34);
            this.dateTimePickerFechaTransaccion.TabIndex = 13;
            // 
            // btnSiguienteNuevaTransaccion
            // 
            this.btnSiguienteNuevaTransaccion.BackColor = System.Drawing.Color.OliveDrab;
            this.btnSiguienteNuevaTransaccion.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSiguienteNuevaTransaccion.Location = new System.Drawing.Point(442, 539);
            this.btnSiguienteNuevaTransaccion.Name = "btnSiguienteNuevaTransaccion";
            this.btnSiguienteNuevaTransaccion.Size = new System.Drawing.Size(357, 57);
            this.btnSiguienteNuevaTransaccion.TabIndex = 15;
            this.btnSiguienteNuevaTransaccion.Text = "Regresar al Menú Principal";
            this.btnSiguienteNuevaTransaccion.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(801, 130);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(368, 287);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // PantallaExito
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1201, 689);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnSiguienteNuevaTransaccion);
            this.Controls.Add(this.dateTimePickerFechaTransaccion);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtMontoNuevaTransaccion);
            this.Controls.Add(this.lbCuentaDestinoTransaccionExitosa);
            this.Controls.Add(this.lbCuentaOrigenTransaccionExitosa);
            this.Controls.Add(this.lbMontoEnviarConfirmacion);
            this.Controls.Add(this.label2);
            this.Name = "PantallaExito";
            this.Text = "PantallaExito";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbMontoEnviarConfirmacion;
        private System.Windows.Forms.Label lbCuentaOrigenTransaccionExitosa;
        private System.Windows.Forms.Label lbCuentaDestinoTransaccionExitosa;
        private System.Windows.Forms.TextBox txtMontoNuevaTransaccion;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePickerFechaTransaccion;
        private System.Windows.Forms.Button btnSiguienteNuevaTransaccion;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}