﻿namespace Parcial_2_Simulador_de_Transacciones_Bancarias
{
    partial class MenuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuPrincipal));
            this.lbUsuarioMenuPrincipal = new System.Windows.Forms.Label();
            this.lbCuentaMenuPrincipal = new System.Windows.Forms.Label();
            this.lbSaldoDisponibleMenuPrincipal = new System.Windows.Forms.Label();
            this.txtUsuarioReadOnly = new System.Windows.Forms.TextBox();
            this.txtCuentaReadOnly = new System.Windows.Forms.TextBox();
            this.txtSaldoReadOnly = new System.Windows.Forms.TextBox();
            this.btnRealizarTransaccion = new System.Windows.Forms.Button();
            this.btnHistorialTransacciones = new System.Windows.Forms.Button();
            this.btnCerrarSesion = new System.Windows.Forms.Button();
            this.lblBienvenida = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbUsuarioMenuPrincipal
            // 
            this.lbUsuarioMenuPrincipal.AutoSize = true;
            this.lbUsuarioMenuPrincipal.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUsuarioMenuPrincipal.Location = new System.Drawing.Point(107, 99);
            this.lbUsuarioMenuPrincipal.Name = "lbUsuarioMenuPrincipal";
            this.lbUsuarioMenuPrincipal.Size = new System.Drawing.Size(117, 38);
            this.lbUsuarioMenuPrincipal.TabIndex = 0;
            this.lbUsuarioMenuPrincipal.Text = "Usuario";
            // 
            // lbCuentaMenuPrincipal
            // 
            this.lbCuentaMenuPrincipal.AutoSize = true;
            this.lbCuentaMenuPrincipal.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCuentaMenuPrincipal.Location = new System.Drawing.Point(107, 197);
            this.lbCuentaMenuPrincipal.Name = "lbCuentaMenuPrincipal";
            this.lbCuentaMenuPrincipal.Size = new System.Drawing.Size(109, 38);
            this.lbCuentaMenuPrincipal.TabIndex = 1;
            this.lbCuentaMenuPrincipal.Text = "Cuenta";
            // 
            // lbSaldoDisponibleMenuPrincipal
            // 
            this.lbSaldoDisponibleMenuPrincipal.AutoSize = true;
            this.lbSaldoDisponibleMenuPrincipal.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSaldoDisponibleMenuPrincipal.Location = new System.Drawing.Point(107, 300);
            this.lbSaldoDisponibleMenuPrincipal.Name = "lbSaldoDisponibleMenuPrincipal";
            this.lbSaldoDisponibleMenuPrincipal.Size = new System.Drawing.Size(238, 38);
            this.lbSaldoDisponibleMenuPrincipal.TabIndex = 3;
            this.lbSaldoDisponibleMenuPrincipal.Text = "Saldo Disponible";
            // 
            // txtUsuarioReadOnly
            // 
            this.txtUsuarioReadOnly.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuarioReadOnly.Location = new System.Drawing.Point(114, 140);
            this.txtUsuarioReadOnly.Name = "txtUsuarioReadOnly";
            this.txtUsuarioReadOnly.ReadOnly = true;
            this.txtUsuarioReadOnly.Size = new System.Drawing.Size(286, 38);
            this.txtUsuarioReadOnly.TabIndex = 4;
            // 
            // txtCuentaReadOnly
            // 
            this.txtCuentaReadOnly.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCuentaReadOnly.Location = new System.Drawing.Point(114, 238);
            this.txtCuentaReadOnly.Name = "txtCuentaReadOnly";
            this.txtCuentaReadOnly.ReadOnly = true;
            this.txtCuentaReadOnly.Size = new System.Drawing.Size(286, 38);
            this.txtCuentaReadOnly.TabIndex = 5;
            // 
            // txtSaldoReadOnly
            // 
            this.txtSaldoReadOnly.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSaldoReadOnly.Location = new System.Drawing.Point(114, 353);
            this.txtSaldoReadOnly.Name = "txtSaldoReadOnly";
            this.txtSaldoReadOnly.ReadOnly = true;
            this.txtSaldoReadOnly.Size = new System.Drawing.Size(286, 38);
            this.txtSaldoReadOnly.TabIndex = 7;
            // 
            // btnRealizarTransaccion
            // 
            this.btnRealizarTransaccion.BackColor = System.Drawing.Color.OliveDrab;
            this.btnRealizarTransaccion.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRealizarTransaccion.ForeColor = System.Drawing.Color.Black;
            this.btnRealizarTransaccion.Location = new System.Drawing.Point(114, 512);
            this.btnRealizarTransaccion.Name = "btnRealizarTransaccion";
            this.btnRealizarTransaccion.Size = new System.Drawing.Size(277, 58);
            this.btnRealizarTransaccion.TabIndex = 8;
            this.btnRealizarTransaccion.Text = "Realizar Transacción";
            this.btnRealizarTransaccion.UseVisualStyleBackColor = false;
            // 
            // btnHistorialTransacciones
            // 
            this.btnHistorialTransacciones.BackColor = System.Drawing.Color.OliveDrab;
            this.btnHistorialTransacciones.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHistorialTransacciones.Location = new System.Drawing.Point(491, 512);
            this.btnHistorialTransacciones.Name = "btnHistorialTransacciones";
            this.btnHistorialTransacciones.Size = new System.Drawing.Size(283, 56);
            this.btnHistorialTransacciones.TabIndex = 9;
            this.btnHistorialTransacciones.Text = "Historial Transacciones";
            this.btnHistorialTransacciones.UseVisualStyleBackColor = false;
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.BackColor = System.Drawing.Color.OliveDrab;
            this.btnCerrarSesion.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrarSesion.Location = new System.Drawing.Point(879, 512);
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.Size = new System.Drawing.Size(226, 57);
            this.btnCerrarSesion.TabIndex = 10;
            this.btnCerrarSesion.Text = "Cerrar Sesión";
            this.btnCerrarSesion.UseVisualStyleBackColor = false;
            // 
            // lblBienvenida
            // 
            this.lblBienvenida.AutoSize = true;
            this.lblBienvenida.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBienvenida.ForeColor = System.Drawing.Color.Green;
            this.lblBienvenida.Location = new System.Drawing.Point(459, 33);
            this.lblBienvenida.Name = "lblBienvenida";
            this.lblBienvenida.Size = new System.Drawing.Size(253, 45);
            this.lblBienvenida.TabIndex = 12;
            this.lblBienvenida.Text = "Menú Principal";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(761, 115);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(344, 292);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // MenuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1232, 631);
            this.Controls.Add(this.lblBienvenida);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnCerrarSesion);
            this.Controls.Add(this.btnHistorialTransacciones);
            this.Controls.Add(this.btnRealizarTransaccion);
            this.Controls.Add(this.txtSaldoReadOnly);
            this.Controls.Add(this.txtCuentaReadOnly);
            this.Controls.Add(this.txtUsuarioReadOnly);
            this.Controls.Add(this.lbSaldoDisponibleMenuPrincipal);
            this.Controls.Add(this.lbCuentaMenuPrincipal);
            this.Controls.Add(this.lbUsuarioMenuPrincipal);
            this.Name = "MenuPrincipal";
            this.Text = "MenuPrincipal";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbUsuarioMenuPrincipal;
        private System.Windows.Forms.Label lbCuentaMenuPrincipal;
        private System.Windows.Forms.Label lbSaldoDisponibleMenuPrincipal;
        private System.Windows.Forms.TextBox txtUsuarioReadOnly;
        private System.Windows.Forms.TextBox txtCuentaReadOnly;
        private System.Windows.Forms.TextBox txtSaldoReadOnly;
        private System.Windows.Forms.Button btnRealizarTransaccion;
        private System.Windows.Forms.Button btnHistorialTransacciones;
        private System.Windows.Forms.Button btnCerrarSesion;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblBienvenida;
    }
}